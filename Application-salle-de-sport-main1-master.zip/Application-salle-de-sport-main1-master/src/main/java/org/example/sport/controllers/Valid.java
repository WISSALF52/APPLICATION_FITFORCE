package org.example.sport.controllers;

public @interface Valid {
}
