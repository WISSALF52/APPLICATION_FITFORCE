package org.example.sport.repositories;

import org.example.sport.entite.ServiceSport;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ServiceSportRepository extends JpaRepository<ServiceSport, Long> {
}

