package org.example.sport.repositories;

import org.example.sport.entite.SeanceCours;
import org.example.sport.entite.SeanceCours;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SeancecoursRepository extends JpaRepository<SeanceCours,Long>{


}