package org.example.sport.entite;

public enum TypeNotification {
    PAIEMENT_REUSSI,
    PAIEMENT_ECHOUE,
    REMBOURSEMENT_INITIE,
    REMBOURSEMENT_TERMINE,
    RAPPEL_PAIEMENT,
    CODE_PROMO_APPLIQUE
}