package org.example.sport.entite;

public enum StatutPaiement {
    EN_ATTENTE,
    TERMINE,
    ECHOUE,
    REMBOURSE_PARTIELLEMENT,
    REMBOURSE_TOTALEMENT,
    CONFIRME, ANNULE
}