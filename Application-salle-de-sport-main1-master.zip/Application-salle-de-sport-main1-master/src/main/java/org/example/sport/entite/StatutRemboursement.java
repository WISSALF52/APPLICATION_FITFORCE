package org.example.sport.entite;

public enum StatutRemboursement {
    EN_COURS,
    TERMINE,
    ECHOUE,
    ANNULE
}