package org.example.sport.controllers;

public @interface Autowire {
}
